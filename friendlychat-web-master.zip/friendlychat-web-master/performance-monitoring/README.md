# Firebase Performance Monitoring for Web Codelab - Final code

This folder contains the final code for the [Firebase Performance Monitoring
for Web Codelab](https://codelabs.developers.google.com/codelabs/firebase-perf-mon-web/). You can see how finished app looks like after integration with Performance Monitoring.

If you'd like to follow the step by step codelab start with the [performance-monitoring-start](../performance-monitoring-start) directory.

